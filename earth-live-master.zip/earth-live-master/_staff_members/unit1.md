---
name: Unit 1
position: Turbulence
---

### Fundamental Turbulence Theory
* define turbulence
* identify the Navier-Stokes equation
* apply the Reynolds decomposition to the Navier Stokes equation to derive mean and second order properties of turbulent flow

