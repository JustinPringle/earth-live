---
name: Gerald Freeman
position: Sales
image_path: https://source.unsplash.com/collection/139386/602x602?a=.png
twitter_username: CloudCannonApp
blurb: Gerald loves going to bike rides and spending time with his family.
---
